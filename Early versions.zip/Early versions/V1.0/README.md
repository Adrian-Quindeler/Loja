# Adrian's & Adrian's LTDA. - Sistema de Loja V1.0
Bem-vindo ao sistema de loja de produtos eletrônicos da "**Adrian's & Adrian's LTDA.**". Este sistema foi desenvolvido com fins de aprendizado em meu primeiro contato com programação, entre 2021/2022. 
É totalmente implementado em Python, roda no terminal e permite que os usuários visualizem produtos, adicionem itens ao carrinho e finalizem suas compras de forma interativa.

## Funcionalidades do Sistema
1. Mostrar Especificações dos Produtos
2. Adicionar Item ao Carrinho
3. Remover Item do Carrinho
4. Mostrar Carrinho
5. Finalizar Compra com CEP para a entrega.